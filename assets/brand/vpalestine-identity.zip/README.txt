VPalestine identity kit

marks/  SVG wordmarks, the V and avatars for white and black stock
fonts/  Anybody and Besley (SIL Open Font License), web subsets
inks.json  the four inks on both stocks

The identity book: index.html of the prototype.
